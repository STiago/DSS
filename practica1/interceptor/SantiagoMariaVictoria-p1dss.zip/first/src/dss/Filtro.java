package dss;

public interface Filtro {
	public double ejecutar(Object peticion);
}
